package com.bank.Transactionstreambackward;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionstreambackwardApplicationTests {

	@Test
	void contextLoads() {
	}

}
