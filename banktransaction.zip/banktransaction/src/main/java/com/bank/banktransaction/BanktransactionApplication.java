package com.bank.banktransaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BanktransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(BanktransactionApplication.class, args);
	}
	

}
