package com.bank.banktransaction.constants;

public class BankConstant {
	
	public static String credit ="Credired";
	
	public static String debit ="Debited";
	
	public static String emaildebit =" rs has been Debited from Your Account";
	
	public static String Erroraccount ="Please Check account Number";
	
	public static String transfer ="Transfered";
	
	public static String accountno="Account Number";
	
	public static String messages ="Message";
	
	public static String status ="Status";
	public static String ok ="200";
	public static String error ="404";
	
	//User Creation
	public static String usercreated="Account Registered Successfully and Your account no is ";
	public static String userids =" And Your User Id is ";
	public static String existphone ="Phone no Already Exist ";
	public static String existemail ="Email Already Exist ";
	
	//Deposit
	
	public static String deposits ="Amount has been creadited ";
	
	public static String emailssubject="Transaction has been done using your Banking Solutions Application";
	
	public static String balance ="  Your Account balance is ";
	public static String notvalidaccno ="Account number doesn't exist";
	
	
	//Add Accounts
	
	public static String accountnumber ="Account added Successfully the Account Number is  ";
	public static String existaccountnumber ="Account Number Already Exist ";
	
	public static String notfoundaccountnumber ="Account Number Not Found ";
	

	

}
