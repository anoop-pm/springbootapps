package com.bank.banktransaction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.banktransaction.model.AddAmount;

public interface AddamountRepository extends JpaRepository<AddAmount, Long> {

}