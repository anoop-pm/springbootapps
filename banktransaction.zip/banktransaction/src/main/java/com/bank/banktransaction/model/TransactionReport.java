package com.bank.banktransaction.model;

public class TransactionReport {

}
