package com.bank.banktransaction.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bank.banktransaction.model.AddAmount;

public interface FindUserid extends JpaRepository<AddAmount, Integer> {

	@Query(value = "select userid from useraccounts u where u.accountnumber =:AccountNumber", nativeQuery = true)
	Integer getuserid(@Param("AccountNumber") int AccountNumber);

	@Query(value = "select id from users u where u.id =:uid", nativeQuery = true)
	Integer getuserbyid(@Param("uid") int uid);

}
