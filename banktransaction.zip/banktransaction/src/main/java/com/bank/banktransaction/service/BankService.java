package com.bank.banktransaction.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.banktransaction.config.ProducerConfigbank;
import com.bank.banktransaction.constants.BankConstant;
import com.bank.banktransaction.model.AddAccount;
import com.bank.banktransaction.model.AddAmount;
import com.bank.banktransaction.model.TransactionDetails;
import com.bank.banktransaction.model.TransactionLog;
import com.bank.banktransaction.model.User;
import com.bank.banktransaction.repository.AddAccountRepositorry;
import com.bank.banktransaction.repository.AddAmountUpdateRepository;
import com.bank.banktransaction.repository.AddamountRepository;
import com.bank.banktransaction.repository.BankRepository;
import com.bank.banktransaction.repository.FindAccountnumberRepository;
import com.bank.banktransaction.repository.FindUserdetails;
import com.bank.banktransaction.repository.FindUserid;
import com.bank.banktransaction.repository.GetamountbalanceRepository;
import com.bank.banktransaction.repository.LogTransactionRepository;
import com.bank.banktransaction.repository.TransactionRepository;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** Class for All Rest API Actions */
@Service
@Transactional
public class BankService {

	@Autowired
	private BankRepository bankRepository;

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private AddamountRepository amountRepostory;

	@Autowired
	private AddAmountUpdateRepository depositRepostory;

	@Autowired
	private TransactionRepository transactionrepostory;

	@Autowired
	private AddAccountRepositorry accountrepository;

	@Autowired
	private FindAccountnumberRepository findaccountnumber;

	@Autowired
	private FindUserid finduser;

	@Autowired
	private GetamountbalanceRepository balancerepository;

	@Autowired
	private FindUserdetails findusers;

	@Autowired
	private LogTransactionRepository logrepo;

	@Autowired
	private ProducerConfigbank producers;

	/**
	 * This Service for Register A User and and Check Unique Email and Password and
	 * OutPut is A Map objects And Service Create a Random Account Number And User
	 * ID Fields Are Fields "name":"Athira", "dateofbirth":"08-08-1995",
	 * "accounttype":"savings", "age":30, "address":"parayil",
	 * "email":"athirakundoor@gmail.com", "phonenumber":"7907730284"
	 */
	private static final Logger logger = LogManager.getLogger(BankService.class);

	public Object saveuser(User user) {

		String emailid = null;
		String phoneno = null;
		int val = 0;

		if (bankRepository.maxuserid() == null) {
			val = 0;
		} else {
			val = bankRepository.maxuserid();
		}
		{
			try {
				emailid = findusers.getEmailaddress(user.getEmail()); // Find Email ID
				phoneno = findusers.getPhonenumber(user.getPhonenumber()); // Find Phone Number
			} catch (Exception e) {
				logger.error(" Oops! Emaild and password =NULL We can create new User ");
			}
		}

		// Random User ID
		Random random = new Random();
		int x = random.nextInt(899) + 100;
		String newuserid = String.valueOf(val + 1) + String.valueOf(x);
		System.out.println(val + "value=" + newuserid);

		// Auto generate account number
		int acc = random.nextInt(8999) + 1000;
		String newaccno = String.valueOf(val + 1) + String.valueOf(acc) + String.valueOf(val);

		Map<String, String> map = new HashMap<>();

		if (emailid == null && phoneno == null) { // Check phone and Email is Unique

			user.setName(user.getName());
			user.setDateofbirth(user.getDateofbirth());
			user.setAge(user.getAge());
			user.setAccounttype(user.getAccounttype());
			user.setAddress(user.getAddress());
			user.setPhonenumber(user.getPhonenumber());
			user.setEmail(user.getEmail());
			user.setUserid(Integer.parseInt(newuserid));
			logger.warn(" Created New User Successfully " + user);

			// Auto created user account
			AddAmount amount = new AddAmount();
			amount.setUserid(Integer.parseInt(newuserid));
			amount.setAccountnumber(Integer.parseInt(newaccno));
			amount.setDeposit(0);
			amountRepostory.save(amount);
			bankRepository.save(user);
			String messages = BankConstant.usercreated + newaccno + " " + BankConstant.userids + newuserid; // Constant
			map.put(BankConstant.status, BankConstant.ok);
			map.put(BankConstant.messages, messages);

		} else if (phoneno != null) {
			map.put(BankConstant.status, BankConstant.error);
			map.put(BankConstant.messages, BankConstant.existphone);

			logger.error(BankConstant.existphone);
		} else if (emailid != null) {
			map.put(BankConstant.status, BankConstant.error);
			map.put(BankConstant.messages, BankConstant.existemail);
			logger.error(BankConstant.existemail);
		} else {
			return "";
		}
		return map;
	}

	/**
	 * This Service For Deposit Amount Using User Account Number Fields
	 * "accountnumber":183090, "deposit":3000
	 */
	public Object deposit(AddAmount addAmount) {

		// validation
		int accountno = 0;
		int userid = 0;
		int newbalance = 0;
		try {
			accountno = findaccountnumber.getaccountnumber(addAmount.getAccountnumber());
			userid = finduser.getuserid(addAmount.getAccountnumber());
			newbalance = balancerepository.getamount(addAmount.getAccountnumber());

		} catch (Exception e) {

			logger.warn("Oops! We have an Error. Account Number Not Match");
		}

		int getaccountno = addAmount.getAccountnumber();

		Map<String, String> map = new HashMap<>();

		if (accountno == getaccountno) {
			int newamount = newbalance + addAmount.getDeposit();
			depositRepostory.updatebalance(addAmount.getDeposit(), addAmount.getAccountnumber(), userid); // Update
			// Balance
			logger.warn("Deposited Successfully");

			TransactionDetails transaction = new TransactionDetails();
			transaction.setUserid(userid);
			transaction.setSenderaccountnumber(addAmount.getAccountnumber());
			transaction.setReceiveraccountnumber(addAmount.getAccountnumber());
			transaction.setAmount(addAmount.getDeposit());
			transaction.setDetails(BankConstant.credit);// constant
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			String Time = timestamp.toString();
			transaction.setTime(Time);
			transactionrepostory.save(transaction);

			String depositmessage = BankConstant.deposits + BankConstant.balance + String.valueOf(newamount);
			map.put(BankConstant.status, BankConstant.ok);
			map.put(BankConstant.messages, depositmessage);

		} else {
			map.put(BankConstant.status, BankConstant.error);
			map.put(BankConstant.messages, BankConstant.notvalidaccno);
		}
		return map;
	}

	/**
	 * For Create Receiver Account Details Fields "receiveraccountnumber":1436,
	 * "name":"silpa", "bankname":"SBI", "ifsccode":"SBIN0012"
	 */
	public Object addAccount(AddAccount addAccount) {

		int receiveraccountnumber = 0;
		Map<String, String> map = new HashMap<>();
		try {
			receiveraccountnumber = findaccountnumber.getreceiveraccountnumber(addAccount.getReceiveraccountnumber());
		} catch (Exception e) {
			logger.error("Receiver number Not found we can add new Account");
		}
		if (receiveraccountnumber == 0) {
			String accountmessage = BankConstant.accountnumber + addAccount.getReceiveraccountnumber();
			map.put(BankConstant.status, BankConstant.ok);
			map.put(BankConstant.messages, accountmessage);
			accountrepository.save(addAccount); // saved New Account
			logger.error("Add new Account Details" + addAccount);

		} else {
			map.put(BankConstant.status, BankConstant.error);
			map.put(BankConstant.messages, BankConstant.existaccountnumber);
			logger.error(BankConstant.existaccountnumber);
		}
		return map;
	}

	/**
	 * This Service for Transfer amount from User account to another Account User
	 * Give SenderAccount Number and Receiver AccountNumber And Amount then this
	 * service send and produce to a Kafka Topic
	 *
	 * Fields
	 *
	 * "senderaccountnumber":183090, "receiveraccountnumber":1436, "amount":900
	 *
	 *
	 */
	public void creditamount(TransactionDetails transferamount) {

		// Kafka Producer
		Producer<String, String> producer = new KafkaProducer<>(producers.kafkaproducer());
		// send json messages as String
		int senderacccountnumber = transferamount.getSenderaccountnumber();
		Integer obj = new Integer(senderacccountnumber);
		String strsenderacccountnumber = obj.toString();

		int amount = transferamount.getAmount();
		Integer obj2 = new Integer(amount);
		String stramount = obj2.toString();

		int receiveraccountnumbeer = transferamount.getReceiveraccountnumber();
		Integer obj3 = new Integer(receiveraccountnumbeer);
		String strreceiveraccountnumbeer = obj3.toString();

		try {
			producer.send(bankTransaction(strsenderacccountnumber, stramount, strreceiveraccountnumbeer));
			Thread.sleep(100);

		} catch (InterruptedException e) {

		}

		producer.close();

	}

	public static ProducerRecord<String, String> bankTransaction(String accno, String amount, String raccno) {

		// creates an empty json {}
		ObjectNode transaction = JsonNodeFactory.instance.objectNode();

		// Instant.now() is to get the current time using Java 8
		Instant now = Instant.now();

		// we write the data to the json document
		transaction.put("SenderAccountnumber", accno);
		transaction.put("ReceiverAccountnumber", raccno);
		transaction.put("amount", amount);
		transaction.put("time", now.toString());
		return new ProducerRecord<>("bankinput", accno, transaction.toString());
	}

	// Consume data
	/**
	 * Listen transactionstreamoutput topic and validate the transaction report to
	 * be transfer or not Then send mail
	 * {"SenderAccountnumberb":256421,"ReceiverAccountnumber":2000,"Reportb":"Transfered","Amountbb":600,"time":"2022-01-21T11:45:00.018Z"}
	 */
	@KafkaListener(topics = "transactionstreamoutput")
	public void consume(String message) throws IOException {

		JSONObject json = new JSONObject(message);

		System.out.println(json.get("SenderAccountnumberb").toString());
		String reportfromtransaction = json.get("Reportb").toString();
		String validss = reportfromtransaction;

		String saccountno = json.get("SenderAccountnumberb").toString();
		int sendereccno = Integer.parseInt(saccountno);

		String raccountno = json.get("ReceiverAccountnumber").toString();
		Integer.parseInt(raccountno);

		String amounttranfer = json.get("Amountbb").toString();
		int amounttranferint = Integer.parseInt(amounttranfer);

		// Store logs
		TransactionLog tralog = new TransactionLog();
		tralog.setLogs(message);
		logrepo.save(tralog);

		int userid2 = 0;
		int accountbalance = 0;
		try {

			accountbalance = balancerepository.getamount(sendereccno);
			userid2 = finduser.getuserid(sendereccno);

		} catch (Exception e) {
			logger.warn("Account number not found");
		}

		String emailid2 = null;
		try {
			emailid2 = findusers.getnewemail(userid2); // find Email id
		} catch (Exception e) {

			logger.warn("Null Exception For checking emailid ");
		}

		String rep = BankConstant.emailssubject + " " + amounttranferint + BankConstant.emaildebit
				+ BankConstant.balance + accountbalance;

		if (validss.equals(BankConstant.transfer)) {
			try {
				sendEmail(rep, emailid2); // call mail method
				logger.warn(rep);
				// sendEmailWithAttachment();
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			logger.warn("Mail Sended to" + emailid2);
		} else {
			logger.error("Some Issues Not Transferd Details" + validss);
		}
	}

	public void sendEmail(String rep, String mailid) {
		// for Send Mail
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(mailid);
		msg.setSubject(" Transaction Status ");
		msg.setText(rep);

		javaMailSender.send(msg); // Send mail
	}

	public String messagereader() {

		String message = transactionrepostory.message(1);
		return message;
	}

	public String statusread() {

		String status = transactionrepostory.status(1);
		return status;
	}

	// Service for Balance Check
	/**
	 * This Service for Check balance Fields
	 *
	 * "accountnumber":128520
	 *
	 **/
	public int balancechek(AddAmount amount) {

		int balance = 0;
		try {
			balance = balancerepository.getamount(amount.getAccountnumber());
			logger.warn("Balance is" + balance);
		} catch (Exception e) {
			logger.error("Error Not found account Number");
		}
		return balance;
	}

}