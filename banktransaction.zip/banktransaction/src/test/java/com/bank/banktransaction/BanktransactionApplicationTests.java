package com.bank.banktransaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanktransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
