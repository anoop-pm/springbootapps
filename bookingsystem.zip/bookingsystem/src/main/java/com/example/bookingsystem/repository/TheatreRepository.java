package com.example.bookingsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.bookingsystem.entity.TheatreDetails;


public interface TheatreRepository extends JpaRepository<TheatreDetails, Long> {

	@Query(value = "select max(id) from theatre_details", nativeQuery = true)
	Integer maxFlightId();

	@Query(value = "select theatre_name from theatre_details u where u.theatre_name =:theatreName", nativeQuery = true)
	String getTheatreName(@Param("theatreName") String theatreName);

}
