package com.example.bookingsystem.entity;

import lombok.ToString;

@ToString
public class CancelationOffer {

	private int flightid;
	private int within4hr;
	private int after4hr;
	private int cancelationcharge;
	private int offers;

	public CancelationOffer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getFlightid() {
		return flightid;
	}

	public void setFlightid(int flightid) {
		this.flightid = flightid;
	}



	public int getWithin4hr() {
		return within4hr;
	}
	public void setWithin4hr(int within4hr) {
		this.within4hr = within4hr;
	}
	public int getAfter4hr() {
		return after4hr;
	}
	public void setAfter4hr(int after4hr) {
		this.after4hr = after4hr;
	}
	public int getCancelationcharge() {
		return cancelationcharge;
	}
	public void setCancelationcharge(int cancelationcharge) {
		this.cancelationcharge = cancelationcharge;
	}
	public int getOffers() {
		return offers;
	}
	public void setOffers(int offers) {
		this.offers = offers;
	}

}