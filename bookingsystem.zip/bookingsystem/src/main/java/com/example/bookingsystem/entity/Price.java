package com.example.bookingsystem.entity;

public class Price {

	private int economic;
	private int business;

	public int getEconomic() {
		return economic;
	}
	public void setEconomic(int economic) {
		this.economic = economic;
	}
	public int getBusiness() {
		return business;
	}
	public void setBusiness(int business) {
		this.business = business;
	}



}
