package com.example.bookingsystem.entity;

public class FindFlight {


	private String dates;


	private String source;

	private String destination;



	public FindFlight() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getDates() {
		return dates;
	}

	public void setDates(String dates) {
		this.dates = dates;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}


}
