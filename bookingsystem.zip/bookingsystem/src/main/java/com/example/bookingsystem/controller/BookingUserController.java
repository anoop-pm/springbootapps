package com.example.bookingsystem.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bookingsystem.dto.SearchFlightTickets;
import com.example.bookingsystem.entity.User;
import com.example.bookingsystem.model.BookingObject;
import com.example.bookingsystem.model.ResponseObject;
import com.example.bookingsystem.repository.BookingFlightRepository;
import com.example.bookingsystem.repository.FlightRepository;
import com.example.bookingsystem.service.BookingService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;



@RestController
@RequestMapping("/bookingapi")
@Api(value = "Ticket Booking Solutions", description = "Book Tickets")
public class BookingUserController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private FlightRepository flightRepository;

	@Autowired
	private BookingFlightRepository bookingFlight;

	@PostMapping("/user/registration")
	@ApiOperation(value = "Register A User")
	public ResponseEntity<ResponseObject> createUser(
			@ApiParam(value = "Register User object store in database table", required = true) @Valid @RequestBody User user) throws SQLException {

		ResponseObject savedUser = bookingService.addUser(user);
		return new ResponseEntity<ResponseObject>(savedUser, HttpStatus.ACCEPTED);
	}

	@GetMapping("/user/bookdetail")
	public ResponseEntity<BookingObject> bookDetails(
			@ApiParam(value = "Register User object store in database table", required = true) @Valid @RequestBody SearchFlightTickets userbookings) throws SQLException {
		BookingObject abc=bookingService.bookTicketDetails(userbookings);
		return new ResponseEntity<BookingObject>(abc, HttpStatus.ACCEPTED);
	}



}
