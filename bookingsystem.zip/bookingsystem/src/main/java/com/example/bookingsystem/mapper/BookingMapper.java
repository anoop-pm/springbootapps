//package com.example.bookingsystem.mapper;
//
//import org.mapstruct.Mapper;
//import org.mapstruct.MappingTarget;
//
//import com.example.bookingsystem.dto.BookDetails;
//import com.example.bookingsystem.entity.FlightBooking;
//
//@Mapper
//public interface BookingMapper {
//
//	BookDetails convertToFlightBooking(FlightBooking bookingFlight);
//
//	FlightBooking updateFlightBookingEntity(BookDetails mobilephoneDto, @MappingTarget FlightBooking flight);
//
//}
