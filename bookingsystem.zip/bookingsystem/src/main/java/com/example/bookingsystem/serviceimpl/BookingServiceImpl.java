package com.example.bookingsystem.serviceimpl;

import java.sql.SQLException;
import java.text.DateFormatSymbols;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.bookingsystem.constant.BookingConstant;
import com.example.bookingsystem.dto.BookDetails;
import com.example.bookingsystem.dto.CancelBooking;
import com.example.bookingsystem.dto.FlightDelete;
import com.example.bookingsystem.dto.SearchFlightTickets;
import com.example.bookingsystem.entity.CancelationOffer;
import com.example.bookingsystem.entity.CancelationRules;
import com.example.bookingsystem.entity.FlightBooking;
import com.example.bookingsystem.entity.FlightDetails;
import com.example.bookingsystem.entity.Passenger;
import com.example.bookingsystem.entity.SearchFlight;
import com.example.bookingsystem.entity.TheatreDetails;
import com.example.bookingsystem.entity.TransactionStatus;
import com.example.bookingsystem.entity.UpdateFlight;
import com.example.bookingsystem.entity.User;
import com.example.bookingsystem.model.BookingObject;
import com.example.bookingsystem.model.FlightObject;
import com.example.bookingsystem.model.ResponseObject;
import com.example.bookingsystem.repository.BookingFlightRepository;
import com.example.bookingsystem.repository.CancelationRuleRepository;
import com.example.bookingsystem.repository.FlightRepository;
import com.example.bookingsystem.repository.PassengerRepository;
import com.example.bookingsystem.repository.TheatreRepository;
import com.example.bookingsystem.repository.TransactionRepository;
import com.example.bookingsystem.repository.UserRepository;
import com.example.bookingsystem.service.BookingService;
import com.example.bookingsystem.utilities.BookingUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private ResponseObject response;

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private FlightRepository flightRepository;

	@Autowired
	private PassengerRepository passengerRepository;

	@Autowired
	private CancelationRuleRepository cancelationRuleRepository;

	@Autowired
	private BookingFlightRepository bookingFlight;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private TheatreRepository theatreRepository;

	@Autowired
	private DataSource dataSource;

	BookingConstant constant = new BookingConstant();

	BookingUtilities utilities = new BookingUtilities();

	FlightObject flightResponce = new FlightObject();

	BookingObject bookingObject = new BookingObject();

	/**
	 * Register A User for store user details identifying email and phone so that
	 * user must follow unique id and phone number in this service identifying
	 * unique phone number and email maxid means get maximum id from the table its
	 * used for generated unique ID email and phone variable for identify unique
	 * value then check the Database Connection then save the User
	 *
	 * INPUT as Json
	 *
	 * { "name":"Arun", "dateofbirth":"08-08-1995", "age":30, "address":"parayil",
	 * "email":"ano4opp@gmail.com", "phonenumber":"8897512866" }
	 *
	 *
	 *
	 */

	@Override
	public ResponseObject addUser(User user) throws SQLException {

		String email = null;
		String phone = null;
		int maxid = 0;
		try {
			email = userRepository.getEmailAddress(user.getEmail());
			phone = userRepository.getPhoneNumber(user.getPhonenumber());
			maxid = userRepository.maxuserid();
			boolean connection = dataSource.getConnection().isValid(1000);
			System.out.println("connection " + connection);
		} catch (Exception e) {
			// logger
		}

		int userid = utilities.randomNumber(4, maxid);
		System.out.println(utilities.validateJavaDate(user.getDateofbirth()));
		boolean dateValid=utilities.validateJavaDate(user.getDateofbirth());
		if(dateValid==false)
		{
			response.setStatus(constant.StatusError);
			response.setMessage("Date of birth not in valid format please follow DD/MM/YEAR");
			return response;
		}
		if (utilities.emailPhoneValid(email, phone) == true) { // Check phone and Email is Unique
			user.setName(user.getName());
			user.setDateofbirth(user.getDateofbirth());
			user.setAge(user.getAge());
			user.setAddress(user.getAddress());
			user.setPhonenumber(user.getPhonenumber());
			user.setEmail(user.getEmail());
			user.setUserid(userid);
			System.out.println("connection Check");
			boolean connection = dataSource.getConnection().isValid(1000);

			System.out.println("connection " + connection);
			if (connection == true) {
				//				userRepository.save(user);
				response.setStatus(constant.StatusOk);
				response.setMessage(constant.UserCreated + userid);
			} else {
				response.setStatus(constant.StatusError);
				response.setMessage(constant.ConnectionError);

			}
		} else {
			response.setStatus(constant.StatusError);
			response.setMessage(constant.EmailPhoneExist);
		}
		return response;
	}

	/**
	 * add Flight This Service for add flight Details
	 *
	 * Maxflight and Flight name used for set Unique value flight name used for
	 * identify flightname already Exist MaxflightID used for Generatinf Random
	 * Unique Number
	 *
	 * Here Economic and Business Seats arranged as List used for loop for that
	 *
	 * ALso default Cancelation Rule Mapped With Generated Flight ID
	 *
	 * Admin can change rules in future
	 *
	 *
	 * Input
	 *
	 * { "flightname":"Air Asia", "businessclassseats":15, "economyclassseats":15,
	 * "times":"10am", "dates":"Thursday", "source":"Nedumbasserry",
	 * "arrivaltime":"9am", "destination":"Dubai",
	 * "price":"{economic:10000,business:30000}" }
	 *
	 */
	@Override
	public ResponseObject addFights(FlightDetails flightDetails) throws SQLException {
		// TODO Auto-generated method stub

		int maxFlightId = 0;
		int businessSeat = 0;
		int economicSeat = 0;
		String flightName = null;

		try {
			maxFlightId = flightRepository.maxFlightId();
			flightName = flightRepository.getFlightName(flightDetails.getFlightname());
		} catch (Exception e) {
			// Logger
		}
		int newFlightId = utilities.randomNumber(5, maxFlightId);
		System.out.println(maxFlightId + "value=" + newFlightId);
		if (flightName == null) {
			flightDetails.setFlightname(flightDetails.getFlightname());
			flightDetails.setBusinessclassseats(flightDetails.getBusinessclassseats());
			flightDetails.setEconomyclassseats(flightDetails.getEconomyclassseats());

			List<Integer> businessList = new ArrayList<>();
			List<Integer> economicList = new ArrayList<>();
			Map<String, List<Integer>> dict = new HashMap<String, List<Integer>>();
			businessSeat = flightDetails.getBusinessclassseats();
			economicSeat = flightDetails.getEconomyclassseats();
			for (int i = 1; i < businessSeat + 1; i++) {
				businessList.add(i);
			}
			for (int i = 1; i < economicSeat + 1; i++) {
				economicList.add(i);
			}
			dict.put(constant.Business, businessList);
			dict.put(constant.Economic, economicList);
			JSONObject json = new JSONObject(dict);
			flightDetails.setSeats(json.toString());
			flightDetails.setDates(flightDetails.getDates());
			flightDetails.setDispaturetimes(flightDetails.getDispaturetimes());
			flightDetails.setDuration(flightDetails.getDuration());
			JSONObject priceJson = new JSONObject(flightDetails.getPrice());
			flightDetails.setPrice(priceJson.toString());
			flightDetails.setSource(flightDetails.getSource());
			flightDetails.setDestination(flightDetails.getDestination());
			flightDetails.setFlightid(newFlightId);

			CancelationRules rules = new CancelationRules();
			Map<String, Integer> ruleMap = new HashMap<String, Integer>();
			ruleMap.put(constant.CancelWithin4, 100);
			ruleMap.put(constant.Before1hr, 40);
			ruleMap.put(constant.CancelationCharge, 4);
			ruleMap.put(constant.Offers, 0);
			JSONObject ruleJson = new JSONObject(ruleMap);
			String defaultRules = ruleJson.toString();
			rules.setBookingsystem("Flight");
			rules.setSystemid(newFlightId);
			Instant now = Instant.now();
			rules.setTime(now.toString());
			rules.setRules(defaultRules);
			boolean connection = dataSource.getConnection().isValid(1000);
			if (connection == true) {
				flightRepository.save(flightDetails);
				cancelationRuleRepository.save(rules);
				response.setStatus(200);
				response.setMessage(constant.FlightDetails + newFlightId);
			} else {
				response.setStatus(404);
				response.setMessage(constant.ConnectionError);
			}
		} else {
			response.setStatus(404);
			response.setMessage(constant.FlightName);
		}
		return response;
	}

	/**
	 * Find Flight
	 *
	 * All flights Are arranged by weekdays
	 *
	 * Here find weekday from given date then Search Flights With given passenger
	 * count ,Destination and Source
	 *
	 * Input
	 *
	 * { "source":"Nedumbasserry", "destination":"Dubai", "dates": "03/03/2022",
	 * "seats":"4"
	 *
	 * }
	 *
	 */
	@Override
	public FlightObject findFlights(SearchFlight flightDetails) throws SQLException {
		// TODO Auto-generated method stub

		boolean dateValid=utilities.validateJavaDate(flightDetails.getDates());
		if(dateValid==false)
		{
			flightResponce.setStatus(400);
			flightResponce.setMessage("PLease Fill Valid Date Format like DD/MM/YEAR");
			return flightResponce;
		}
		Date date = new Date();
		String dayWeekText = null;
		try {
			dayWeekText = utilities.dateDay(flightDetails.getDates());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("day" + dayWeekText + "date" + date);
		List<FlightDetails> flightDetailsList = null;
		String flightList = null;
		int noOfSeat = Integer.parseInt(flightDetails.getSeats());
		try {
			flightDetailsList = flightRepository.getFlight(dayWeekText, flightDetails.getDestination(),
					flightDetails.getSource(), noOfSeat);
			flightList = flightDetailsList.toString();
		} catch (Exception e) {
			// logger
		}
		if (flightList != null) {
			flightResponce.setStatus(200);
			flightResponce.setMessage(constant.FlightDetailsList);
			flightResponce.setFlightList(flightDetailsList);
		} else {
			flightResponce.setStatus(400);
			flightResponce.setMessage(constant.FlightNotAvailable);
		}
		return flightResponce;
	}

	/**
	 * Book Tickets
	 *
	 * After Seatching Flight application use this api for book Tickets
	 *
	 * Different Validation Happen here for Given data is valuevable for book
	 * Tickets like flight id is currect and given seats are available or not ETC
	 *
	 * Here 2 Entity Class used Flight booking and Passenger
	 *
	 * Passenger is mapped with list<passenger> in Flightbooking
	 *
	 * This passenger List used for Store Passenger
	 *
	 * This api also used for blocking Tickets
	 *
	 * Input
	 *
	 * { "flightid": 22417, "passengers": [ { "name": "jayasree", "age": "23",
	 * "uniqueId": "c11234785" }, { "name": "priyanka", "age": "22", "uniqueId":
	 * "c23545" } ], "seats": "{economic:[2],business:[2]}", "mail":
	 * "anoopmohan08@gmail.com", "userid": 1473 } after hit the request send a mail
	 * to given and user mail id
	 *
	 * *Differnt Generic method is used like Search,addseat,removeseat,price,count
	 * All generic method are defined in Utilities Package
	 *
	 */
	@Override
	public ResponseObject bookTickets(FlightBooking bookFlight) throws SQLException {
		// TODO Auto-generated method stub
		int flightId = 0;
		int systemId = 0;
		String cancelRule = null;
		String seatPrice = null;
		String availableSeat = null;

		String seats = bookFlight.getSeats();
		JSONObject seatJson = new JSONObject(seats);
		String economicSeat = seatJson.get(constant.Economic).toString();
		String businessSeat = seatJson.get(constant.Business).toString();
		List<String> selectEconomicList = utilities.createList(economicSeat);
		List<String> selectBusinessList = utilities.createList(businessSeat);
		int bookingid = 0;
		int maxBookId = 0;
		int userId = 0;
		try {
			flightId = flightRepository.getFlightId(bookFlight.getFlightid());
			systemId = cancelationRuleRepository.getSystemId(bookFlight.getFlightid());
			cancelRule = cancelationRuleRepository.getrule(systemId);
			seatPrice = flightRepository.getPrice(flightId);
			availableSeat = flightRepository.getSeats(flightId);
			userId = userRepository.getUserIds(bookFlight.getUserid());
			maxBookId = bookingFlight.maxBookId();
		} catch (Exception e) {
			// logger
		}

		boolean seatSearchEconomic = false;
		boolean seatSearchBusiness = false;
		List<String> newEconomicList=null;
		List<String> newBusinessList=null;
		int sizeEco = 0;
		int sizeBis = 0;
		int sizeofSeats=0;
		float afteroffers=0;
		if(flightId != 0 && systemId != 0) {
			System.out.println(userId + "userid" + bookFlight.getUserid()+flightId+"ss"+systemId);
			bookingid = utilities.randomNumber(5, maxBookId);
			JSONObject availableSeatJson = new JSONObject(availableSeat);
			String economicSeats = availableSeatJson.get(constant.Economic).toString();
			String businessSeats = availableSeatJson.get(constant.Business).toString();
			newEconomicList = utilities.createList(economicSeats);
			newBusinessList = utilities.createList(businessSeats);
			seatSearchEconomic = utilities.search(newEconomicList, selectEconomicList);
			seatSearchBusiness = utilities.search(newBusinessList, selectBusinessList);
			System.out.println("searched e" + seatSearchEconomic + seatSearchBusiness);
			JSONObject ruleJson = new JSONObject(cancelRule);
			JSONObject price = new JSONObject(seatPrice);
			int business = (int) price.get(constant.Business);
			int economic = (int) price.get(constant.Economic);
			int offers = (int) ruleJson.get(constant.Offers);
			int economicPrice;
			int businessPrice;

			if (selectEconomicList.get(0) != "") {
				economicPrice = selectEconomicList.size() * economic;
			} else {
				economicPrice = selectEconomicList.size() * 0;
			}
			if (selectBusinessList.get(0) != "") {
				businessPrice = selectBusinessList.size() * business;
			} else {
				businessPrice = selectBusinessList.size() * 0;
			}

			int totalAmount = economicPrice + businessPrice;

			afteroffers = totalAmount - totalAmount * (offers / 100);
			if (selectEconomicList.size() == 1) {
				newEconomicList.remove(selectEconomicList.get(0));
				sizeEco = utilities.sizeOfList(selectEconomicList);
			} else {
				newEconomicList = utilities.removeSeat(newEconomicList, selectEconomicList);
				sizeEco = selectEconomicList.size();
			}
			if (newBusinessList.size() == 1) {
				newBusinessList.remove(newBusinessList.get(0));
				sizeBis = utilities.sizeOfList(selectBusinessList);
			} else {
				newBusinessList = utilities.removeSeat(newBusinessList, selectBusinessList);
				sizeBis = selectBusinessList.size();
			}
			sizeofSeats = sizeEco + sizeBis;
			System.out.println("Size is" + sizeofSeats + "vs" + bookFlight.getPassengers().size());
		}
		else {
			System.out.println("Error");
			response.setStatus(404);
			response.setMessage("Flight id Not Exist please give Valid Flight ID");
			return response;
		}

		if (flightId != 0 && systemId != 0 && userId != 0 && seatSearchEconomic == true && seatSearchBusiness == true
				&& bookFlight.getPassengers().size() == sizeofSeats) {
			boolean connection = dataSource.getConnection().isValid(1000);
			if (connection == true) {

				Map<String, List<Integer>> dict = new HashMap<String, List<Integer>>();
				List<Integer> integerList = newEconomicList.stream().map(Integer::valueOf).collect(Collectors.toList());
				List<Integer> integerBList = newBusinessList.stream().map(Integer::valueOf)
						.collect(Collectors.toList());
				dict.put(constant.Business, integerBList);
				dict.put(constant.Economic, integerList);
				JSONObject newSeatJson = new JSONObject(dict);
				flightRepository.updateSeat(newSeatJson.toString(), flightId);
				bookFlight.setBookingid(bookingid);
				bookFlight.setUserid(userId);
				bookFlight.setAmount((int) afteroffers);
				String flightDate = flightRepository.getDate(flightId);
				String destination = flightRepository.getDestination(flightId);
				String source = flightRepository.getSource(flightId);
				String time = flightRepository.getTime(flightId);
				String flightName = flightRepository.getFlightNameByid(flightId);
				bookFlight.setDate(flightDate);
				bookFlight.setDestination(destination);
				bookFlight.setSource(source);
				bookFlight.setFlightname(flightName);
				bookFlight.setTime(time);
				bookFlight.setSeats(bookFlight.getSeats());
				bookFlight.setFlightid(flightId);
				bookFlight.setPaymentstatus("notpayed");
				bookFlight.setPaymentoption("notpayed");
				bookFlight.setMail(bookFlight.getMail());
				Instant now = Instant.now();
				bookFlight.setBookedtime(now.toString());
				int numberEconomicSeat = flightRepository.getNumberEconomicSeat(flightId);
				int numberBusinessSeat = flightRepository.getNumberBusinessSeat(flightId);
				int newNumberEconomicSeat = numberEconomicSeat - selectEconomicList.size();
				int newNumberBusinessSeat = numberBusinessSeat - selectBusinessList.size();
				flightRepository.updateEconomicSeat(newNumberEconomicSeat, flightId);
				flightRepository.updateBusinessSeat(newNumberBusinessSeat, flightId);
				bookingFlight.save(bookFlight);
				int newbookId = 0;

				try {
					Thread.sleep(2000);
					newbookId = bookingFlight.getBookMapId(bookingid);

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				List<Passenger> passengerList = new ArrayList<Passenger>();
				passengerList = passengerRepository.getpassenger(newbookId);
				Map<String, Passenger> passengerdict = new HashMap<String, Passenger>();
				for (int i = 0; i < passengerList.size(); i++) {
					Passenger name = passengerList.get(i);
					passengerdict.put("passenger" + i, name);
				}

				String passengerJson = null;
				try {
					passengerJson = new ObjectMapper().writeValueAsString(passengerdict);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				JSONObject newSeatJsonPass = new JSONObject(passengerJson);

				System.out.println(newSeatJsonPass.toString());
				System.out.println(
						"Available Economic Seats " + newEconomicList + "Available Business Seats " + newBusinessList
						+ "id" + newbookId + "Passenger" + passengerJson + bookFlight.getPassengers().size()
						+ "Available Seat " + newNumberEconomicSeat + " " + newNumberBusinessSeat);
				response.setStatus(200);

				String emailUserId = userRepository.getEmailId(userId);

				String mailContent =  " Your Booking ID IS " + bookingid+BookingConstant.PAYABLEAMOUNT + afteroffers + BookingConstant.PassengerDetails
						+ newSeatJsonPass.toString() + "Your Seats" + selectEconomicList + selectBusinessList
						+ BookingConstant.CONFIRMBILL ;
				sendEmail(mailContent, emailUserId);
				sendEmail(mailContent, bookFlight.getMail());
				response.setMessage(mailContent);
			} else {
				response.setStatus(404);
				response.setMessage(constant.ConnectionError);
			}
		} else if (seatSearchEconomic != true && seatSearchBusiness != true) {
			response.setStatus(404);
			response.setMessage("Seat Not Available");
		} else {
			response.setStatus(404);
			response.setMessage(constant.BookUserFlightId);
		}
		return response;
	}

	@Override
	public List<FlightBooking> getAllPassangersCustom(int page) {
		int size = 3;
		Pageable pagable = PageRequest.of(page, size);
		return bookingFlight.findAll(pagable).toList();
	}

	/**
	 * Confirm Booking
	 *
	 * This Service used for confirm our booking with payment After Payment user and
	 * given mail id Got Confirm Ticket And Status Change to Payed
	 *
	 * Input
	 *
	 * { "bookingid":28837, "paymentoption":"UPI" }
	 *
	 */
	@Override
	public ResponseObject bookTicketsConfirm(TransactionStatus bookDeails) throws SQLException {
		int bookidcount = bookingFlight.searchId(bookDeails.getBookingid());
		int max = 0;
		String mail=null;
		String paymentStatus=null;
		int bookAmount=0;
		try {
			bookAmount=bookingFlight.amount(bookDeails.getBookingid());
			paymentStatus=bookingFlight.getPaymentStatus(bookDeails.getBookingid());
			max = transactionRepository.maxTransactionId();
		} catch (Exception e) {
			max = 0;
		}
		System.out.println(paymentStatus+"paymnetStatus"+bookAmount);
		if(bookAmount != bookDeails.getAmount()) {
			response.setStatus(404);
			response.setMessage(constant.AmountNotMatch);
			return response;
		}
		if (bookidcount != 0 && bookAmount == bookDeails.getAmount() && paymentStatus.equals("notpayed")) {
			bookingFlight.updatePayment("payed", bookDeails.getBookingid());
			bookingFlight.updatePaymentOption(bookDeails.getPaymentoption(), bookDeails.getBookingid());

			bookDeails.setTransferstatus("Booking");
			bookDeails.setPaymentoption(bookDeails.getPaymentoption());
			bookDeails.setUserid(bookDeails.getUserid());
			int selectAmount = bookingFlight.amount(bookDeails.getBookingid());
			bookDeails.setAmount(selectAmount);
			String transactionID = "TRA" + utilities.randomNumber(5, max);
			bookDeails.setTransactionid(transactionID);
			bookDeails.setBookingid(bookDeails.getBookingid());
			bookDeails.setCardnumber(bookDeails.getCardnumber());
			bookDeails.setCvv(bookDeails.getCvv());
			bookDeails.setValidthrough(bookDeails.getValidthrough());
			transactionRepository.save(bookDeails);
			response.setStatus(200);
			response.setMessage(constant.PAYMENTSUCCESS);
		} else {
			response.setStatus(404);
			response.setMessage(constant.PAYMENTNOTSUCCESS);
		}
		return response;
	}

	public void sendEmail(String rep, String mailid) {
		// for Send Mail
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(mailid);
		msg.setSubject(" Flight Booking Status ");
		msg.setText(rep);
		javaMailSender.send(msg); // Send mail
	}

	/**
	 *
	 * CancelFlightTicket Service Used for cancel Tickets After validation Service
	 * Cancel Given Seats Here Remove Method is used for cancel tickets remove given
	 * seats from booked Tickets and add to Flight seat list
	 *
	 * After cancellation User Got confirmation ,
	 *
	 * Input
	 *
	 *
	 * { "bookingid": 28837, "seats": "{economic:[5],business:[5]}" }
	 *
	 *
	 * Different Generic method is used like Search,addseat,removeseat,price,count
	 * All generic method are defined in Utilities Package
	 *
	 */

	@Override
	public ResponseObject cancelFlightTicket(CancelBooking bookDeails) throws SQLException {
		// TODO Auto-generated method stub

		String cancelRule = null;
		String seatPrice = null;
		String availableSeat = null;

		String seats = bookDeails.getSeats();
		JSONObject seatJson = new JSONObject(seats);
		String economicSeat = seatJson.get(constant.Economic).toString();
		String businessSeat = seatJson.get(constant.Business).toString();
		List<String> selectEconomicList = utilities.createList(economicSeat);
		List<String> selectBusinessList = utilities.createList(businessSeat);
		System.out.println(selectEconomicList+""+selectBusinessList);
		int flightId = 0;
		int systemId = 0;
		int userId = 0;
		String availableBookSeat = null;
		String bookedTime = null;
		try {
			flightId = bookingFlight.searchFlightId(bookDeails.getBookingid());
			systemId = cancelationRuleRepository.getSystemId(flightId);
			userId = userRepository.getUserIds(bookDeails.getUserid());
			cancelRule = cancelationRuleRepository.getrule(flightId);
			seatPrice = flightRepository.getPrice(flightId);
			availableSeat = flightRepository.getSeats(flightId);
			availableBookSeat = bookingFlight.getBookSeats(bookDeails.getBookingid());
			bookedTime = bookingFlight.getBookedTime(bookDeails.getBookingid());

		} catch (Exception e) {
			// logger

			System.out.println("error happened in try"+flightId+"s"+systemId+"u"+userId+cancelRule+seatPrice+availableSeat+availableBookSeat+bookedTime);
		}
		if(flightId==0) {

			response.setStatus(404);
			response.setMessage(constant.NOTMATCHBOOKING);
			return response;
		}
		JSONObject availableSeatJson = new JSONObject(availableSeat);
		String economicSeats = availableSeatJson.get(constant.Economic).toString();
		String businessSeats = availableSeatJson.get(constant.Business).toString();
		List<String> newEconomicList = utilities.createList(economicSeats);
		List<String> newBusinessList = utilities.createList(businessSeats);
		System.out.println("values"+flightId+"s"+systemId+"u"+userId+cancelRule+seatPrice+availableSeat+availableBookSeat+bookedTime+"and"+newEconomicList+""+newBusinessList);

		boolean seatSearchEconomic = utilities.search(newEconomicList, selectEconomicList);
		boolean seatSearchBusiness = utilities.search(newBusinessList, selectBusinessList);
		System.out.println(newEconomicList+"serach"+selectEconomicList);
		System.out.println(newBusinessList+"bookedbissserach"+selectBusinessList);
		if (selectEconomicList.size() == 1) {
			newEconomicList.add(selectEconomicList.get(0));

		} else {
			newEconomicList = utilities.addSeat(newEconomicList, selectEconomicList);

		}
		if (newBusinessList.size() == 1) {
			newBusinessList.add(newBusinessList.get(0));
		} else {
			newBusinessList = utilities.addSeat(newBusinessList, selectBusinessList);
		}
		flightRepository.updateEconomicSeat(newEconomicList.size(), flightId);
		flightRepository.updateBusinessSeat(newBusinessList.size(), flightId);
		System.out.println(newEconomicList+"added"+newBusinessList);
		JSONObject availableBookSeatJson = new JSONObject(availableBookSeat);
		String economicBookSeats = availableBookSeatJson.get(constant.Economic).toString();
		String businessBookSeats = availableBookSeatJson.get(constant.Business).toString();
		List<String> newEconomicBookList = utilities.createList(economicBookSeats);
		List<String> newBusinessBookList = utilities.createList(businessBookSeats);
		boolean seatSearchBookEconomic = utilities.search(newEconomicBookList, selectEconomicList);
		boolean seatSearchBookBusiness = utilities.search(newBusinessBookList, selectBusinessList);
		System.out.println(newEconomicBookList+"bookedserach"+selectEconomicList);
		System.out.println(newBusinessBookList+"bookedserach"+selectBusinessList);
		if (selectEconomicList.size() == 1) {
			newEconomicBookList.remove(selectEconomicList.get(0));

		} else {
			newEconomicBookList = utilities.removeSeat(newEconomicBookList, selectEconomicList);

		}
		if (selectBusinessList.size() == 1) {
			newBusinessBookList.remove(selectBusinessList.get(0));
		} else {
			newBusinessBookList = utilities.removeSeat(newBusinessBookList, selectBusinessList);
		}
		System.out.println(newEconomicBookList+"afterremove"+newBusinessBookList);
		System.out.println(seatSearchBookEconomic+"" + seatSearchBookBusiness+"" + seatSearchEconomic
				+""+ seatSearchBusiness );
		System.out.println(seatSearchBookEconomic+"afterremove"+seatSearchBookBusiness);
		if (seatSearchBookEconomic == true && seatSearchBookBusiness == true && seatSearchEconomic == false
				&& seatSearchBusiness == false) {

			Map<String, List<Integer>> dict = new HashMap<String, List<Integer>>();
			List<Integer> integerList = newEconomicList.stream().map(Integer::valueOf).collect(Collectors.toList());
			List<Integer> integerBList = newBusinessList.stream().map(Integer::valueOf).collect(Collectors.toList());
			dict.put(constant.Business, integerBList);
			dict.put(constant.Economic, integerList);
			JSONObject newSeatJson = new JSONObject(dict);
			flightRepository.updateSeat(newSeatJson.toString(), flightId);

			Map<String, List<Integer>> dictBook = new HashMap<String, List<Integer>>();
			List<Integer> integerListBook = newEconomicBookList.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> integerBListBook = newBusinessBookList.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			dictBook.put(constant.Business, integerBListBook);
			dictBook.put(constant.Economic, integerListBook);
			JSONObject newSeatBookJson = new JSONObject(dictBook);
			bookingFlight.updateSeat(newSeatBookJson.toString(), bookDeails.getBookingid());
			Instant instant1 = Instant.parse(bookedTime);
			Instant now = Instant.now();
			long difference = ChronoUnit.HOURS.between(instant1, now);
			// Cancel Amount
			JSONObject ruleJson = new JSONObject(cancelRule);
			JSONObject price = new JSONObject(seatPrice);
			int business = (int) price.get(constant.Business);
			int economic = (int) price.get(constant.Economic);
			int offers = (int) ruleJson.get(constant.Offers);
			int cancelfour = (int) ruleJson.get(constant.CancelWithin4);
			int cancelationCharge = (int) ruleJson.get(constant.CancelationCharge);
			int aftercancel = (int) ruleJson.get(constant.Before1hr);
			int afterAppliedCharge=0;
			int economicPrice;
			int businessPrice;

			if (selectEconomicList.get(0) != "") {
				economicPrice = selectEconomicList.size() * economic;
			} else {
				economicPrice = selectEconomicList.size() * 0;
			}
			if (selectBusinessList.get(0) != "") {
				businessPrice = selectBusinessList.size() * business;
			} else {
				businessPrice = selectBusinessList.size() * 0;
			}
			int totalAmount = economicPrice + businessPrice;
			TransactionStatus transaction = new TransactionStatus();
			transaction.setTransferstatus("Cancel");
			transaction.setPaymentoption("Card");
			int max = 0;
			try {
				max = transactionRepository.maxTransactionId();
			} catch (Exception e) {
				max = 0;
			}

			String transactionID = "TRA" + utilities.randomNumber(5, max);
			transaction.setTransactionid(transactionID);

			if (difference <= 4) {
				afterAppliedCharge = (totalAmount * cancelfour) / 100;
				System.out.println("insideif"+afterAppliedCharge);
			}

			else {

				afterAppliedCharge = (totalAmount * aftercancel )/ 100;
				System.out.println("outsideIF"+afterAppliedCharge);
			}

			String emailUserId = userRepository.getEmailId(userId);
			afterAppliedCharge=(afterAppliedCharge*cancelationCharge)/100;
			String mailContent = "Cancelation Successful your Canceled Seat is" + seatJson + "Seat Amount"
					+ totalAmount
					+ "After Cancelation Charges Applied The amount will transerd to your account within 2days amount is"
					+ afterAppliedCharge;

			sendEmail(mailContent, emailUserId);
			transaction.setAmount(afterAppliedCharge);
			System.out.println("time Difference" + bookedTime + "n" + now.toString() + "diff" + difference + "cancel"
					+ cancelfour + aftercancel + "aaa " + afterAppliedCharge + "bbb " + totalAmount);
			transactionRepository.save(transaction);
			response.setStatus(200);
			response.setMessage(constant.CANCELED+constant.AMOUNT+afterAppliedCharge);

		} else {
			response.setStatus(404);
			response.setMessage("Selected Seat and Booking ID Not Matched Please Check");
		}

		return response;

	}





	@Override
	public ResponseObject deleteFlight(FlightDelete delete) throws SQLException {
		// TODO Auto-generated method stub
		int flightId =0;
		try {
			flightId = flightRepository.getFlightId(delete.getFlightid());
		}
		catch(Exception e) {

		}
		System.out.println("Flight ID"+flightId);
		if(flightId!=0)
		{
			flightRepository.deleteFlight(flightId);
			response.setStatus(200);
			response.setMessage(constant.FLIGHTID+delete.getFlightid()+constant.DELETED);
		}
		else {
			response.setStatus(404);
			response.setMessage(constant.NOTMATCHEDFLIGHTID);
		}
		return response;


	}

	@Override
	public ResponseObject cancelationRuleUpdate(CancelationOffer cancelUpdate) throws SQLException {
		// TODO Auto-generated method stub

		int systemId=0;
		try {

			systemId = cancelationRuleRepository.getSystemId(cancelUpdate.getFlightid());
		}
		catch(Exception e) {

		}
		if(systemId!=0)
		{
			Map<String, Integer> ruleMap = new HashMap<String, Integer>();
			ruleMap.put(constant.CancelWithin4, cancelUpdate.getWithin4hr());
			ruleMap.put(constant.Before1hr, cancelUpdate.getAfter4hr());
			ruleMap.put(constant.CancelationCharge, cancelUpdate.getCancelationcharge());
			ruleMap.put(constant.Offers, cancelUpdate.getOffers());
			JSONObject ruleJson = new JSONObject(ruleMap);
			String defaultRules = ruleJson.toString();
			cancelationRuleRepository.updateCancelRule(defaultRules, cancelUpdate.getFlightid());

			response.setStatus(200);
			response.setMessage(cancelUpdate.getFlightid()+"Flight rules has been Updated");
		}
		else {
			response.setStatus(404);
			response.setMessage(constant.NOTMATCHEDFLIGHTID);
		}
		return response;
	}

	@Override
	public ResponseObject addTheatre(TheatreDetails theatreDetails) throws
	SQLException {
		// TODO Auto-generated method stub

		int maxTheatreId = 0;
		int businessSeat = 0;
		int economicSeat = 0;
		String theatreName = null;
		//
		try {
			maxTheatreId = theatreRepository.maxFlightId();
			theatreName=theatreRepository.getTheatreName(theatreDetails.getTheatrename());
		} catch (Exception e) {
			// Logger
		}
		int newTheateId = utilities.randomNumber(5, maxTheatreId);
		System.out.println(maxTheatreId + "value=" + newTheateId);
		if (theatreName == null) {
			theatreDetails.setTheatrename(theatreDetails.getTheatrename());
			theatreDetails.setBusinessclassseats(theatreDetails.getBusinessclassseats());
			theatreDetails.setEconomyclassseats(theatreDetails.getEconomyclassseats());
			//
			List<Integer> businessList = new ArrayList<>();
			List<Integer> economicList = new ArrayList<>();
			Map<String, List<Integer>> dict = new HashMap<String, List<Integer>>();
			businessSeat = theatreDetails.getBusinessclassseats();
			economicSeat = theatreDetails.getEconomyclassseats();
			for (int i = 1; i < businessSeat + 1; i++) {
				businessList.add(i);
			}
			for (int i = 1; i < economicSeat + 1; i++) {
				economicList.add(i);
			}
			dict.put(constant.Business, businessList);
			dict.put(constant.Economic, economicList);

			JSONObject json = new JSONObject(dict);
			theatreDetails.setSeats(json.toString());
			theatreDetails.setTodate(theatreDetails.getTodate());
			theatreDetails.setFromdate(theatreDetails.getFromdate());
			theatreDetails.setTimes(theatreDetails.getTimes());
			theatreDetails.setMoviename(theatreDetails.getMoviename());
			theatreDetails.setLocation(theatreDetails.getLocation());
			JSONObject priceJson = new JSONObject(theatreDetails.getPrice());
			theatreDetails.setPrice(priceJson.toString());
			theatreDetails.setTheaterid(newTheateId);
			CancelationRules rules = new CancelationRules();
			Map<String, Integer> ruleMap = new HashMap<String, Integer>();
			ruleMap.put(constant.CancelWithin4, 100);
			ruleMap.put(constant.Before1hr, 40);
			ruleMap.put(constant.CancelationCharge, 4);
			ruleMap.put(constant.Offers, 0);
			JSONObject ruleJson = new JSONObject(ruleMap);
			String defaultRules = ruleJson.toString();
			rules.setBookingsystem("Theater");
			rules.setSystemid(newTheateId);
			Instant now = Instant.now();
			rules.setTime(now.toString());
			rules.setRules(defaultRules);
			boolean connection = dataSource.getConnection().isValid(1000);
			if (connection == true) {
				theatreRepository.save(theatreDetails);
				cancelationRuleRepository.save(rules);
				response.setStatus(200);
				response.setMessage(constant.MOVIEADDED + newTheateId);
			} else {
				response.setStatus(404);
				response.setMessage(constant.ConnectionError);
			}
		} else {
			response.setStatus(404);
			response.setMessage(constant.AlREADYEXISTTHEATRE);
		}
		return response;
	}

	@Override
	public FlightObject findTheater(SearchFlight flightDetails) throws SQLException {
		// TODO Auto-generated method stub

		//		boolean dateValid=utilities.validateJavaDate(flightDetails.getDates());
		//		if(dateValid==false)
		//		{
		//			flightResponce.setStatus(400);
		//			flightResponce.setMessage("PLease Fill Valid Date Format like DD/MM/YEAR");
		//			return flightResponce;
		//		}
		//		Date date = new Date();
		//		String dayWeekText = null;
		//		try {
		//			dayWeekText = utilities.dateDay(flightDetails.getDates());
		//		} catch (Exception e1) {
		//			// TODO Auto-generated catch block
		//			e1.printStackTrace();
		//		}
		//		System.out.println("day" + dayWeekText + "date" + date);
		//		List<FlightDetails> flightDetailsList = null;
		//		String flightList = null;
		//		int noOfSeat = Integer.parseInt(flightDetails.getSeats());
		//		try {
		//			flightDetailsList = flightRepository.getFlight(dayWeekText, flightDetails.getDestination(),
		//					flightDetails.getSource(), noOfSeat);
		//			flightList = flightDetailsList.toString();
		//		} catch (Exception e) {
		//			// logger
		//		}
		//		if (flightList != null) {
		//			flightResponce.setStatus(200);
		//			flightResponce.setMessage(constant.FlightDetailsList);
		//			flightResponce.setFlightList(flightDetailsList);
		//		} else {
		//			flightResponce.setStatus(400);
		//			flightResponce.setMessage(constant.FlightNotAvailable);
		//		}
		return flightResponce;
	}


	@Override
	public BookingObject bookTicketDetails(SearchFlightTickets bookDeails) throws SQLException {
		// TODO Auto-generated method stub
		int bookingId=0;
		int userid=0;
		int flightId = 0;
		int systemId = 0;
		int userId = 0;
		try {
			flightId = bookingFlight.searchFlightId(bookDeails.getBookingid());
			systemId = cancelationRuleRepository.getSystemId(flightId);
			userId = bookingFlight.searchUserId(bookDeails.getUserid());
		}
		catch(Exception e){}
		BookDetails bookDetail =new BookDetails();
		if(flightId!=0 && userId!=0) {

			System.out.println(flightId+""+userId);

			bookDetail.setBookingid(bookDeails.getBookingid());
			bookDetail.setDate(bookingFlight.getDay(bookDeails.getBookingid()));
			bookDetail.setDestination(flightRepository.getDestination(flightId));
			bookDetail.setFlightid(flightId);
			bookDetail.setUserid(bookDeails.getUserid());
			bookDetail.setSource(flightRepository.getSource(flightId));
			bookDetail.setSeats(bookingFlight.getBookSeats(bookDeails.getBookingid()));
			bookDetail.setTime(flightRepository.getTime(flightId));
			bookingObject.setMessage("messss");
			bookingObject.setStatus(200);
			bookingObject.setBookdetails(bookDetail);

		}
		else {
			bookingObject.setMessage("messss");
			bookingObject.setStatus(404);
			bookingObject.setBookdetails(null);
		}


		//		try {
		//			dates = utilities.datebetween();
		//		} catch (ParseException e) {
		//			// TODO Auto-generated catch block
		//			e.printStackTrace();
		//		}



		return bookingObject;

	}

	@Override
	public ResponseObject updateFlight(UpdateFlight update) throws SQLException {
		// TODO Auto-generated method stub
		int flightID=0;
		try {
			flightID = flightRepository.getFlightId(update.getFlight_id());}
		catch(Exception e){

		}
		boolean checkDay=utilities.validDay(update.getDates());
		if(checkDay==false) {
			response.setStatus(404);
			response.setMessage("Please Enter Valid Day [Sunday\n"
					+ "Monday\n"
					+ "Tuesday\n"
					+ "Wednesday\n"
					+ "Thursday\n"
					+ "Friday\n"
					+ "Saturday]");
			return response;
		}
		if(flightID==update.getFlight_id()) {
			Map<String, Integer> dict = new HashMap<String, Integer>();
			dict.put("business", update.getPrice().getBusiness());
			dict.put("economic", update.getPrice().getEconomic());
			JSONObject price = new JSONObject(dict);
			String[] days = new DateFormatSymbols().getWeekdays();

			//			flightRepository.updateFlight(update.getDates(), update.getTime(), price.toString(), flightID);
			response.setMessage(price+""+dict+
					"Details"+update.getDates()+update.getFlight_id()+update.getTime()+update.getPrice().getBusiness()+update.getPrice().getEconomic()+days+checkDay);
			response.setStatus(200);
			return response;
		}
		else {
			response.setStatus(404);
			response.setMessage(constant.NOTMATCHEDFLIGHTID);
			return response;
		}
	}}
