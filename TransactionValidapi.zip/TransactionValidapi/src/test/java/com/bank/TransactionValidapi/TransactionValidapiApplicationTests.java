package com.bank.TransactionValidapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionValidapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
