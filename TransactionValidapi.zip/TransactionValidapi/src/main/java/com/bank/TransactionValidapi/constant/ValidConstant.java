package com.bank.TransactionValidapi.constant;

public class ValidConstant {

	public static String credit = "Credired";
	public static String debit = "Debited";
	public static String Erroraccount = "Not Transfered Sender Account Number doesn't exist";
	public static String Errorrecaccount = "Not Transfered Receiver Account Number doesn't exist";
	public static String transfer = "Transfered";
	public static String transferemail = "Your Transaction is Successfully Completed ";
	public static String transferemail2 = " You will get a mail after the transaction is complete ";
	public static String accountno = " Account Number ";
	public static String balance = " rupees Your Account Balance is ";
	public static String notenoughbalance = " Account has Not Enough Balance ";

	public static String ok = "200";
	public static String error = "404";

}
