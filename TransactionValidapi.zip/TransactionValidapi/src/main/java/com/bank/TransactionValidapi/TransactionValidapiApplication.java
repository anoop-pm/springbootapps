package com.bank.TransactionValidapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionValidapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionValidapiApplication.class, args);
	}

}
