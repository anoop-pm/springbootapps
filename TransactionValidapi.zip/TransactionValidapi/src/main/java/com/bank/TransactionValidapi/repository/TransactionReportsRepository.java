package com.bank.TransactionValidapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.bank.TransactionValidapi.entity.TransactionReport;



public interface TransactionReportsRepository extends JpaRepository <TransactionReport, Long>
{
//
//	@Transactional
//	@Modifying
//	@Query("UPDATE useraccounts SET balance  = :balance WHERE userid = :userid")
//	Integer updatebalance(int balance, int userid);
//
	
	@Query(value="select userid from useraccounts u where u.accountnumber =:AccountNUmber", nativeQuery=true)
	Integer getuserid(@Param("AccountNUmber") int AccountNUmber);
	
	@Query(value="select accountnumber from useraccounts u where u.accountnumber =:SendAccountNumber", nativeQuery=true)
	Integer getaccountnumber(@Param("SendAccountNumber") int SendAccountNumber);
	

	@Query(value="select receiveraccountnumber from accounts u where u.receiveraccountnumber =:ReceiverAccountNumber", nativeQuery=true)
	Integer getreceiveraccountnumber(@Param("ReceiverAccountNumber") int ReceiverAccountNumber);
	
	@Query(value="select deposit from useraccounts u where u.accountnumber =:AccountNumberB", nativeQuery=true)
	Integer getdeposit(@Param("AccountNumberB") int AccountNumberB);
	
	@Transactional
	@Modifying
	@Query(value="update useraccounts u set u.deposit =:Amount where u.accountnumber =:AccountNumberforUpdate", nativeQuery=true)
	Integer updatebalance(@Param("Amount") int Amount ,@Param("AccountNumberforUpdate") int AccountNumberforUpdate);
	
	
	

	 
}